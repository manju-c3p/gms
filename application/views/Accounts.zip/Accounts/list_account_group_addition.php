 <!-- Static Table Start -->
        <div class="data-table-area mg-tb-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline13-list">
                            <!--<div class="sparkline13-hd">
                                <div class="main-sparkline13-hd">
                                    <h1>Products <span class="table-project-n">Data</span> Table</h1>
                                </div>
                            </div>-->
                            <div class="sparkline13-graph">
                                <div class="datatable-dashv1-list custom-datatable-overright">
                                    
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr class="headings">
                   	<th>Account Code</th>
                  	<th>Group Name</th>
                  	<th>Account Type</th>
                  	<th>Parent Group</th>
                 <!-- 	<th>Action</th>-->
            	</tr>
                </thead>
                <tbody>
                 	<?php foreach ($account_records as $row) : ?>  
                    <tr>
                    	<td><?php echo $row->group_code;?></td>
                    	<td><?php echo $row->group_name ;?></td>
                    	<td><?php if($row->pandl==0) echo 'Balance Sheet'; else echo 'Profit and Loss' ;?></td>
                    	<td><?php echo $row->parent ;?></td>                    	
                     <!--	<td>
		                 	<a href="<?php echo base_url() . 'index.php/Accounts/edit_account_group_form/'.$row->group_no;?>" title="Edit" class="btn btn-sm bg-red"><span class="fa fa-edit"></span></a>
		                  	<a title="Delete" class="btn btn-sm bg-red" href="javascript:delete_area(<?php echo $row->group_no;?>)"><span class="fa fa-trash"></span></a> 
						</td> -->
	                </tr> 
	                 <?php endforeach; ?> 
                </tbody>
              </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Static Table End -->
