<?php  
	foreach ($gen_ledger_records as $row ) {
		$account_id=$row->account_id;
   		$ac_no = $row->account_name;
		$ac_grp = $row->group_no;		
		$op_bal =$row->opening_balance;
		$opening_balance = $row->opening_balance;
		$opening_bal_type = $row->opening_bal_type;
	}
	
?>   
 <!-- Basic Form Start -->
<div class="basic-form-area mg-tb-15" >
    <div class="container-fluid">
        <div class="row">                   
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sparkline9-list responsive-mg-b-30">
                    <!--<div class="sparkline9-hd">
                        <div class="main-sparkline9-hd">
                            <h1>Company Details <span class="basic-ds-n">add</span></h1>
                            <br>
                        </div>
                    </div>-->
                    <div class="sparkline9-graph">
                        <div class="basic-login-form-ad">                                    
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
         			<form class="form-horizontal" method="post" action="<?php echo base_url() . 'index.php/'; ?>Accounts/update_general_ledger_records" id="gen_ledger">
         				<div class="box-body">         				
	         				<div class="form-group">
								<label  class="col-sm-2 control-label">Account Name</label>
								<div class="col-sm-4">
									<input type="text" class="form-control col-sm-2 input-sm" id="ac_name" name="ac_name" readonly="" value="<?php echo $ac_no;?>">
								</div>
							</div>
							<div class="form-group">
								<label  class="col-sm-2 control-label">Account Group</label>
								<div class="col-sm-4">
								  <select name="ac_group" disabled="" id="ac_group" class="form-control select2" >
										<option value="">Select</option>
											<?php foreach($account_records as $row) { ?>
	                   	    				<option <?php if($row->group_no == $ac_grp) echo 'selected'; ?>  value="<?php echo $row->group_no; ?>"><?php echo $row->group_name; ?></option>
											<?php } ?>
								 </select>
								</div>
	         				</div>
	         					
	         				<div class="form-group">
								<label  class="col-sm-2 control-label">Opening Balance</label>
								<div class="col-sm-4">
									<input type="text" class="form-control col-sm-2 input-sm" id="opening_bal" name="opening_bal" value="<?php echo $opening_balance;?>" >
								</div>
							</div>
							
						<div class="form-group">
                          <label class="col-sm-2 control-label">Opening Balance Type</label>
							<div class="col-sm-4">
                           	 <select class="form-control " id="dr_cr_type" name="dr_cr_type" >
                           	 	<option value="">Select Dr/Cr Type</option>
                            	<option <?php if($opening_bal_type='Dr') echo "Selected";?> value='Dr' >DR</option>
                            	<option <?php if($opening_bal_type='Cr') echo "Selected"?> value='Cr' >CR</option>
                           	 </select>
                            </div>
                	   </div>
                	   
         				<div class="col-sm-offset-3">
         					<input type="hidden" id="account_id" name="account_id" value="<?php echo $account_id;?>" >
         													
								<button type="submit" name="add" class="btn btn-primary ">Update</button>
								<button type="reset" class="btn btn-primary">Reset</button>
						</div>
						
         			</form> <!-- End form -->
          		

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
               
    </div>
</div>

<script>

$('#gen_ledger').validate({
		rules : {

			opening_bal: {
				required : true,
				number : true,
				
			},

			 dr_cr_type: {
				required : true,

			},
			 
		},

		messages : {

			opening_bal : {
				required : "Please enter Opening Balance",
			},
			 
			 dr_cr_type: {
				required : "Please Select DR/CR Type",
			},
			
		},

		highlight : function(element) {
			var id_attr = "#" + $(element).attr("id") + "1";
			$(element).closest('.form-group').removeClass('has-success').addClass('has-error');
			$(id_attr).removeClass('glyphicon glyphicon-ok').addClass('glyphicon glyphicon-remove');
		},
		unhighlight : function(element) {
			var id_attr = "#" + $(element).attr("id") + "1";
			$(element).closest('.form-group').removeClass('has-error').addClass('has-success');
			$(id_attr).removeClass('glyphicon glyphicon-remove').addClass('glyphicon glyphicon-ok');
		},
		errorElement : 'span',
		errorClass : 'help-block',
		errorPlacement : function(error, element) {
			if (element.length) {
				error.insertAfter(element);
			} else {
				error.insertAfter(element);
			}
		}
	});

</script>
