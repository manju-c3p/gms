<div class="card-body">
  <form class="form-horizontal" action="<?php echo base_url().'index.php/accounts/add_receipt_details'; ?>" id="receipt" method="post" name="receipt">
    
    <div class="form-group row align-items-center">
      <!-- Date -->
      <div class="col-md-4">
        <label class="form-label">Date <span class="text-danger">*</span></label>
        <div class="input-group date datepicker1">
          <input type="text" class="form-control form-control-sm datepicker1" id="v_date" name="v_date" value="<?php echo date('d-m-Y')?>" required tabindex="1">
          <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
        </div>
      </div>

      <!-- Customer -->
      <div class="col-md-4">
        <label class="form-label">Select Customer <span class="text-danger">*</span></label>
        <select name="debtor" id="debtor" class="form-control select2" onchange="get_invoice_list()" required>
          <option value="">Select</option>
          <?php foreach($receipt_Creditors as $s) { ?>
            <option value="<?php echo $s->account_id; ?>" data-customer-id="<?php echo $s->customer_id; ?>">
              <?php echo $s->account_name ;?>
            </option>
          <?php } ?>
        </select>
        <input type="hidden" name="customer_id" id="customer_id" value="">
      </div>

      <!-- Transaction Type -->
      <div class="col-md-4">
        <label class="form-label">Transaction Type <span class="text-danger">*</span></label>
        <select class="form-control form-control-sm select2" name="transaction_type" id="transaction_type" onchange="toggleTransactionFields()" required>
          <option value="">Select</option>
          <option value="cheque">Cheque</option>
          <option value="etransfer">E-Transfer</option>
          <option value="other">Other</option>
        </select>
      </div>
    </div>

    <div class="col-md-3">
      <label class="form-label">Instrument Date <span class="text-danger">*</span></label>
      <div class="input-group date datepicker1">
        <input type="text" class="form-control form-control-sm datepicker1" id="instrument_bank_date" name="instrument_bank_date"
               value="<?php echo date('d-m-Y')?>" required tabindex="1">
        <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
      </div>
    </div>

    <!-- Conditional Fields: Transaction No & Bank Name -->
    <div class="form-group row" id="transaction_fields" style="display: none;">
      <div class="col-md-4">
        <label class="form-label" id="transaction_label">Transaction No</label>
        <input type="text" class="form-control form-control-sm" name="transaction_no" id="transaction_no" placeholder="Enter Cheque No / Transaction ID">
      </div>
      <!-- Uncomment and fix if you want to use bank name field
      <div class="col-md-4" id="bank_field" style="display: none;">
        <label class="form-label">Bank Name</label>
        <input type="text" class="form-control form-control-sm" name="bank_name" id="bank_name" placeholder="Enter Bank Name">
      </div>
      -->
    </div>

    <!-- Invoice Details -->
    <div class="form-group row">
      <label class="col-sm-12" id="invoice_details"></label>
    </div>

    <!-- Receipt Details -->
    <div class="form-group row">
      <label class="col-sm-2 col-form-label">Receipt Details:</label>
    </div>

    <!-- Invoice List Output -->
    <div class="form-group row">
      <div class="col-md-12" id="debt_list"></div>
    </div>

    <!-- Credit Table -->
    <div class="form-group row">
      <div class="col-md-12">
        <table class="table table-bordered table-hover" id="cr_table">
          <thead>
            <tr>
              <th>Credit Account (Cr)</th>
              <th>Credit Amount</th>
              <th width="10%">
                <a id="cr_add_row" title="Add" class="btn btn-sm bg-orange" style="cursor:pointer;">
                  <span class="fa fa-plus"></span>
                </a>
              </th>
            </tr>
          </thead>
          <tbody id="cr_body">
            <tr id="cr_addr0">
              <td>
                <select class="form-select form-control-sm select2" id="creditor0" name="creditor[]" onchange="get_account_balance(0,'cr')" required>
                  <option value="">Select</option>
                  <?php foreach($sundry_detors_records as $row) { ?>
                    <option value="<?php echo $row->account_id; ?>"><?php echo $row->account_name; ?></option>
                  <?php } ?>
                </select>
                <br><label id="set_balancecr0">Balance</label>
              </td>
              <td>
                <input type="number" step="0.01" name="cr_amount[]" id="cr_amount0" class="form-control form-control-sm credit_sum" min="0" required onkeyup="calculate_grand_total()">
              </td>
              <td>
                <a onclick="remove_row_cr(0)" class="btn btn-xs bg-orange remove1" title="Delete" style="cursor:pointer;">
                  <span class="fa fa-trash"></span>
                </a>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Totals -->
    <div class="form-group row">
      <label class="col-sm-2 col-form-label">Debit Total</label>
      <div class="col-sm-3">
        <input class="form-control bg-soft-gray control-sm" id="debit_total" name="debit_total" type="text" value="" readonly>
      </div>
      <label class="col-sm-2 col-form-label">Credit Total</label>
      <div class="col-sm-3">
        <input class="form-control bg-soft-gray control-sm" id="credit_total" name="credit_total" type="text" value="" readonly>
      </div>
    </div>

    <!-- Narration -->
    <div class="form-group row">
      <label class="col-sm-2 col-form-label">Narration:</label>
      <div class="col-sm-8">
        <textarea class="form-control" id="narration" name="narration"></textarea>
      </div>
    </div>

    <!-- Submit -->
    <div class="form-group row">
      <div class="col-sm-12 text-center">
        <input type="hidden" id="vtime" name="vtime" value="<?php echo date('h:i:s'); ?>" />
        <input type="hidden" id="selected_invoice_ids" name="selected_invoice_ids" />
        <input type="hidden" id="filtered_invoice_codes" name="filtered_invoice_codes" />
        <input type="hidden" id="check_dr_id" name="check_dr_id" value="" />
        <button type="submit" class="btn btn-primary m-b-0" onclick="return check_total();">Save</button>
        <button type="reset" class="btn btn-secondary m-b-0">Reset</button>
      </div>
    </div>

  </form>
</div>

<script>
  function updateSelectedInvoiceIds() {
    let selected = [];
    document.querySelectorAll('input[name="invoiceID[]"]:checked').forEach(function(cb) {
      selected.push(cb.value);
    });
    document.getElementById('selected_invoice_ids').value = selected.join(',');
  }

  function toggleTransactionFields() {
    const type = document.getElementById("transaction_type").value;
    const transactionFields = document.getElementById("transaction_fields");
    //const bankField = document.getElementById("bank_field"); // Uncomment if using bank field
    const label = document.getElementById("transaction_label");

    // Close select2 dropdown
    $('#transaction_type').select2('close');

    if (type === 'cheque') {
      transactionFields.style.display = 'flex';
      //bankField.style.display = 'block'; // Uncomment if using bank field
      label.innerHTML = 'Cheque Number <span class="text-danger">*</span>';
    } else if (type === 'etransfer') {
      transactionFields.style.display = 'flex';
      //bankField.style.display = 'block'; // Uncomment if using bank field
      label.innerHTML = 'Transaction ID <span class="text-danger">*</span>';
    } else if (type === 'other') {
      transactionFields.style.display = 'flex';
      //bankField.style.display = 'none'; // Uncomment if using bank field
      label.innerHTML = 'Remarks <span class="text-danger">*</span>';
      //document.getElementById("bank_name").value = '';
    } else {
      transactionFields.style.display = 'none';
      document.getElementById("transaction_no").value = '';
      //document.getElementById("bank_name").value = '';
    }
  }

  $(document).ready(function(){
    var k=1; // credit row counter (0 exists)

    $('#cr_add_row').click(function() {
      let newRow = `
        <tr id="cr_addr${k}">
          <td>
            <select class="form-select form-control-sm select2" id="creditor${k}" name="creditor[]" onchange="get_account_balance(${k},'cr')" required>
              <option value="">Select</option>
              <?php foreach($sundry_detors_records as $row) { ?>
                <option value="<?php echo $row->account_id; ?>"><?php echo $row->account_name; ?></option>
              <?php } ?>
            </select>
            <br><label id="set_balancecr${k}">Balance</label>
          </td>
          <td>
            <input type="number" step="0.01" name="cr_amount[]" id="cr_amount${k}" class="form-control form-control-sm credit_sum" min="0" required onkeyup="calculate_grand_total()">
          </td>
          <td>
            <a onclick="remove_row_cr(${k})" class="btn btn-xs bg-orange remove1" title="Delete" style="cursor:pointer;">
              <span class="fa fa-trash"></span>
            </a>
          </td>
        </tr>
      `;
      $('#cr_body').append(newRow);
      // Initialize select2 for new row
      $('#creditor'+k).select2({width:"220px"});
      k++;
    });
  });

  function remove_row_cr(id) {
    $('#cr_addr' + id).remove();
    calculate_grand_total();
  }

  function get_account_balance(append_id, type) {
    var tmp = (type == 'dr') ? 'debtor' : 'creditor';
    var account_id = document.getElementById(tmp + append_id).value;
    var today = "<?php echo date('Y-m-d')?>";

    $.ajax({
      url: "<?php echo site_url('Accounts/get_account_balance'); ?>",
      type: 'POST',
      data: {account_id: account_id, today: today},
      success: function(msg) {
        if (msg) {
          document.getElementById('set_balance' + type + append_id).innerHTML = 'Balance: ' + msg;
        }
      }
    });
  }

  function calculate_grand_total() {
    var i_total = 0;
    $('.debit_sum').each(function() {
      var val = parseFloat($(this).val()) || 0;
      i_total += val;
    });

    var k_total = 0;
    $('.credit_sum').each(function() {
      var val = parseFloat($(this).val()) || 0;
      k_total += val;
    });

    $('#debit_total').val(i_total.toFixed(2));
    $('#credit_total').val(k_total.toFixed(2));
  }

  function check_total() {
    var dr_total = parseFloat($('#debit_total').val()) || 0;
    var cr_total = parseFloat($('#credit_total').val()) || 0;
    if (dr_total !== cr_total) {
      alert("Both debit total and credit total must match");
      return false;
    }
    return true;
  }

  function get_invoice_list() {
    var debtorSelect = document.getElementById('debtor');
    var account_id = debtorSelect.value;

    // Get customer_id from selected option data attribute
    var customer_id = debtorSelect.options[debtorSelect.selectedIndex]?.getAttribute('data-customer-id');
    document.getElementById('customer_id').value = customer_id || '';

    if (account_id != '') {
      $.ajax({
        url: "<?php echo site_url('Ajax/get_invoice_list'); ?>",
        type: 'POST',
        data: { account_id: account_id },
        success: function(msg) {
          document.getElementById('debt_list').innerHTML = msg;
        }
      });
    } else {
      document.getElementById('debt_list').innerHTML = '';
    }
  }

  // Call this on checkbox invoiceID[] click to update selected_invoice_ids hidden input
  // function p_check() {
  //   let selected = [];
  //   document.querySelectorAll('input[name="invoiceID[]"]:checked').forEach(function(cb) {
  //     selected.push(cb.value);
  //   });
  //   document.getElementById('selected_invoice_ids').value = selected.join(',');
  // }

function p_check() {
  let selectedIds = [];
  let selectedCodes = [];

  $('.case').each(function () {
    let invoiceId = $(this).val();
    let drInput = $('input[name="dr_amount[' + invoiceId + ']"]');
    let invoiceCode = $(this).data('invoice-code');  // get invoice code from data attribute

    if ($(this).is(':checked')) {
      drInput.prop('disabled', false);
      selectedIds.push(invoiceId);
      if(invoiceCode) selectedCodes.push(invoiceCode);
    } else {
      drInput.prop('disabled', true).val('');
    }
  });

  $('#selected_invoice_ids').val(selectedIds.join(','));
  $('#filtered_invoice_codes').val(selectedCodes.join(','));
}


</script>
