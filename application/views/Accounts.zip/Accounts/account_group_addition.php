<div class="card-body">
	<form class="form-horizontal" method="post" action="<?php echo base_url() . 'index.php/'; ?>Accounts/add_account_group_records" id="account">
			<div class="box-body">   				
					<div class="form-group">						
					<label class="col-sm-2 control-label">Account Group Name</label>
					<div class="col-sm-4">
						<input type="text" class="form-control col-sm-2 input-sm" id="ac_group" name="ac_group" placeholder="Account Group Name">
					</div>			 
 			</div>		
 			      				
			<div class="form-group">
					<label  class="col-sm-2 control-label">Parent Group</label>
					<div class="col-sm-4">
						<select name="p_group" id="p_group" class="form-control select2">
						 	<option value="0">Self</option>
								<?php foreach($parent_records as $row) { ?>
   	    				<option value="<?php echo $row->group_no; ?>"><?php echo $row->group_name; ?></option>
								<?php } ?>
						</select>	
					</div>
			</div>
			<div class="form-group">
					<label  class="col-sm-2 control-label">Section In Accounts</label>
					<div class="col-sm-4">
						<select name="sec_in_account" id="sec_in_account" class="form-control ">
							<option value="">Select</option>
								<?php foreach($section_records as $row) { ?>
   	    				<option value="<?php echo $row->group_no; ?>"><?php echo $row->group_name; ?></option>
								<?php } ?>
						</select>
					</div>
						 
			</div>	
			<div class="col-sm-offset-2">								
				<button type="submit" name="add" class="btn bg-red ">Submit</button>
				<a target="blank" href="<?php echo base_url() . 'index.php/Accounts/view_general_ledger_account_form'?>" title="" class="btn bg-red">Create Ledger Account</span></a>
				<button type="reset" class="btn bg-red ">Reset</button>
			</div>
						
         			</form>

        </div>
    </div>
</div>
</div>
</div>
</div>


<script>
$("#p_group").change(function()
{  	
  	var p_group =document.getElementById('p_group').value; 
  	 $.ajax({     	 	 	
        'type': "POST",
 	    'url':"<?php echo base_url()?>index.php/Ajax/get_parent_account_group",          
        'data':{group_no:p_group},
        'success': function(msg){   
       		$('#sec_in_account').val(msg);	
       	}
	});
});


$('#account').validate({
		rules : {

			 ac_group: {
				required : true,

		        	},
			 p_group: {
				required : true,

			},
			 
		},

		messages : {

			ac_group : {
				required : "Please enter Account group",
			},
			 
			 p_group: {
				required : "Please Select Parent group",
			},
			
		},

		highlight : function(element) {
			var id_attr = "#" + $(element).attr("id") + "1";
			$(element).closest('.form-group').removeClass('has-success').addClass('has-error');
			$(id_attr).removeClass('glyphicon glyphicon-ok').addClass('glyphicon glyphicon-remove');
		},
		unhighlight : function(element) {
			var id_attr = "#" + $(element).attr("id") + "1";
			$(element).closest('.form-group').removeClass('has-error').addClass('has-success');
			$(id_attr).removeClass('glyphicon glyphicon-remove').addClass('glyphicon glyphicon-ok');
		},
		errorElement : 'span',
		errorClass : 'help-block',
		errorPlacement : function(error, element) {
			if (element.length) {
				error.insertAfter(element);
			} else {
				error.insertAfter(element);
			}
		}
	});

</script>
