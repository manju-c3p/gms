<link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>

<div class="bg-white rounded-2xl shadow border p-6">

    <form class="space-y-6"
        action="<?php echo base_url() . 'index.php/Accounts/view_bank_reconciliation'; ?>"
        id="receipt"
        method="post"
        name="receipt">

        <!-- Header -->
        <div class="flex justify-between items-center">
            <h2 class="text-xl font-semibold text-gray-700">
                Bank Reconciliation
            </h2>

            <a href="<?= base_url('index.php/Accounts/bank_reconciliation_list') ?>"
                class="bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-medium">
                List Records
            </a>
        </div>

        <!-- Filters Row -->
        <div class="flex flex-wrap items-end gap-6">

            <!-- Select Account -->
            <div class="w-80">
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    Select Account <span class="text-red-500">*</span>
                </label>

                <select tabindex="1"
                    class="w-full border border-gray-300 rounded-lg px-3 py-2 select2"
                    id="account_id"
                    name="account_id"
                    required
                    onchange="get_doc_list()">

                    <option value="">Select Code</option>

                    <?php foreach ($account_ledgers as $s) { ?>
                        <option <?php if ($s->account_id == $account_id) echo 'selected'; ?>
                            value="<?php echo $s->account_id; ?>">
                            <?php echo $s->account_name; ?>
                        </option>
                    <?php } ?>

                </select>
            </div>

            <!-- From -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    From
                </label>

                <input type="date"
                    class="border border-gray-300 rounded-lg px-3 py-2"
                    id="from_date"
                    name="from_date"
                    onchange="get_doc_list()">
            </div>

            <!-- To -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    To
                </label>

                <input type="date"
                    class="border border-gray-300 rounded-lg px-3 py-2"
                    id="to_date"
                    name="to_date"
                    onchange="get_doc_list()" />
            </div>

        </div>

        <!-- Reconciliation List -->
        <div id="reco_list" class="w-full pt-4">
            <!-- ajax table -->
        </div>

        <!-- Remarks -->
        <div class="w-96">
            <label class="block text-sm font-medium text-gray-700 mb-1">
                Remarks
            </label>

            <textarea id="remark"
                name="remark"
                rows="2"
                placeholder="remark"
                tabindex="5"
                class="w-full border border-gray-300 rounded-lg px-3 py-2"></textarea>
        </div>

        <!-- Submit -->
        <div>
            <button type="submit"
                tabindex="6"
                id="add"
                class="bg-blue-600 hover:bg-blue-700 text-white px-8 py-2 rounded-lg shadow font-medium">
                Submit
            </button>
        </div>

    </form>

</div>


<!-- Static Table End -->



<script>
	function confirmcancel(tid) {
		var r = confirm("Are you sure you want to Delete Record?");
		if (r == true) {
			$.ajax({
				url: "<?php echo base_url() ?>index.php/Ajax/delete_record",
				type: "POST",
				data: {
					table_name: 'bank_reconciliation',
					where_key: 'reconciliation_id',
					where_val: tid
				},
				success: function(msg) {
					if (msg == 1) {
						// alert("Record deleted");
						window.location.href = "<?php echo $_SERVER['PHP_SELF'] ?>";
					} else {
						alert("Can't Delete record. Data already exist!!!");
					}
				},
			});
			return true;
		} else
			return false;

	}
</script>
<script>
	$(document).ready(function() {
		$('#datatable').DataTable({
			pageLength: 10,
			lengthMenu: [10, 25, 50, 100],
			order: [
				[0, 'asc']
			], // Sr.no
			searching: true,
			paging: true,
			info: true,
			autoWidth: false,
			responsive: true,
			columnDefs: [{
					orderable: false,
					targets: -1
				} // Disable sorting on Action column
			]
		});
	});
</script>
