 <!-- Basic Form Start -->
<div class="basic-form-area mg-tb-15" >
    <div class="container-fluid">
        <div class="row">                   
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sparkline9-list responsive-mg-b-30">
                    <!--<div class="sparkline9-hd">
                        <div class="main-sparkline9-hd">
                            <h1>Company Details <span class="basic-ds-n">add</span></h1>
                            <br>
                        </div>
                    </div>-->
                    <div class="sparkline9-graph">
                        <div class="basic-login-form-ad">                                    
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
         			<form class="form-horizontal" method="post" action="<?php echo base_url() . 'index.php/'; ?>Accounts/add_general_ledger_records" id="gen_ledger">
         				<div class="box-body">         				
	         					         				
							<div class="form-group">
			                          <label  class="col-sm-2 control-label">Account Type</label>
									  <div class="col-sm-4">
			                           	 <select class="form-control" id="account_type" name="account_type" onchange="show_list_div(this.value);">
			                           	 	<option value="">Please select account type</option>
			                            	<option value="CUS">Customer/Sundry Debtors</option>
			                            	<option value="SUPP">Vendor/Supplier/Sundry Creditors</option>
			                            	<option value="OTHER">Others</option>
			                           	 </select>
		                              </div>
			                  </div>
	         			     
	         			     <!--<div class="form-group">
								<label  class="col-sm-2 control-label">Account Code</label>
								<div class="col-sm-4">
									<input type="text" class="form-control col-sm-2 input-sm" id="ac_code" name="ac_code" placeholder="Account Code" onblur="check_acc_code_exist(this.value,'general_ledger','account_code', 'ac_code');" >
								</div>
							</div>-->
	         			      				
	         				<div class="form-group" id="show_other" style="display: none;">
								<label  class="col-sm-2 control-label">Account Name</label>
								<div class="col-sm-4">
									<input type="text" class="form-control col-sm-2 input-sm" id="ac_name" name="ac_name" placeholder="Account Name"  >
								</div>
							</div>
    												
							<div class="form-group" id="show_visitor" style="display: none;" >
								<label  class="col-sm-2 control-label">Select Customer</label>
								<div class="col-sm-4">
									<select name="CUS" id="inward_from" class="form-control select2 " onchange="check_account_name_exist();">
				     			   		<option value="">Select</option>
					      			  	<?php foreach($customer_records as $row) { ?>
	    								<option value="<?php echo $row->occu_name.','.$row->occupier_id; ?>"><?php echo $row->occu_name; ?></option>
	       	    						<?php } ?>
				    	    		</select>
								</div>
							</div>
							<div class="form-group" id="show_vendor" style="display: none;" onchange="check_account_name_exist();">
								<label  class="col-sm-2 control-label">Select Vendor/Supplier</label>
								<div class="col-sm-4">
									<select name="SUPP" id="inward_from" class="form-control select2 ">
				     			   		<option value="">Select</option>
					      			  	<?php foreach($supplier_records as $row) { ?>
	    								<option value="<?php echo $row->supp_name.','.$row->supp_id; ?>"><?php echo $row->supp_name; ?></option>
	       	    						<?php } ?>
				    	    		</select>
								</div>
							</div>							
							
							<div class="form-group">
								<label  class="col-sm-2 control-label">Account Group</label>
								<div class="col-sm-4">
								  <select name="ac_group" id="ac_group" class="form-control select2">
										<option value="">Select</option>
											<?php foreach($account_records as $row) { ?>
	                   	    				<option value="<?php echo $row->group_no; ?>"><?php echo $row->group_name; ?></option>
											<?php } ?>
								 </select>
								</div>
	         				</div>
	         					
	         				<div class="form-group">
								<label  class="col-sm-2 control-label">Opening Balance</label>
								<div class="col-sm-4">
									<input type="text" class="form-control col-sm-2 input-sm" id="opening_bal" name="opening_bal" placeholder="Opening Balance">
								</div>
							</div>
							
							<div class="form-group">
	                          <label  class="col-sm-2 control-label">Opening Balance Type</label>
								<div class="col-sm-4">
	                           	 <select class="form-control" id="dr_cr_type" name="dr_cr_type" >
	                           	 	<option value="">Select Dr/Cr Type</option>
	                            	<option value="Cr">Cr</option>
	                           	    <option value='Dr'>Dr</option>
	                           	 </select>
	                            </div>
	                	   </div>
								
	         				<div class="col-sm-offset-2">								
								<button type="submit" name="add" class="btn btn-primary ">Submit</button>
								<a target="blank" href="<?php echo base_url() . 'index.php/Accounts/view_account_group_form'?>" title="" class="btn btn-primary">Create Group</span></a>
								<button type="reset" class="btn btn-primary">Reset</button>
							</div>
						
         			</form> <!-- End form -->
          		

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
               
    </div>
</div>

<script>

function check_acc_code_exist(post_value, table_name, column_name, input_name)
{
	//var ac_code = document.getElementById("ac_code").value;
	//alert(ac_code);
	if(post_value!='')
	{
		$.ajax({     	 	 	
	        'type': "POST",
	 	    'url':"<?php echo base_url()?>index.php/Ajax/check_record_exist",          
	        'data':{code:post_value, tb_name:table_name, column: column_name},
	        //'dataType':"json",
	        'success': function(msg)
	        { 
	        	if(msg==1)
	        	{
	        	 alert('Account Code already exist');
	        	 document.getElementById(input_name).value='';
	        	}
	       	}
		});
	}
}

function show_list_div(acc_type)
  {
  	
  	
	  if(acc_type == 'CUS')
  	 {
  	 	
  		document.getElementById("show_visitor").style.display='block';
  		document.getElementById("show_vendor").style.display='none';
  		document.getElementById("show_other").style.display='none';
  	 }
  	 else if (acc_type == 'SUPP')
  	 {
  	 	
  		document.getElementById("show_visitor").style.display='none';
  		document.getElementById("show_vendor").style.display='block';
  		document.getElementById("show_other").style.display='none';
  		
  	 }
  	 else if (acc_type == 'OTHER')
  	 {
  	 	
  		document.getElementById("show_visitor").style.display='none';
  		document.getElementById("show_vendor").style.display='none';
  		document.getElementById("show_other").style.display='block';
  		
  	 }
  	 multi_select();
  }

$('#gen_ledger').validate({
		rules : {
		  account_type: {
				required : true,
		  },
		  ac_code: {
				required : true,
				maxlength: 9,
		  },
		  ac_name: {
			required : true,
		  },
		  ac_group: {
				required : true,
		  },
		  opening_bal: {
				required : true,
				number : true,
				
			},
		 dr_cr_type: {
				required : true,
			},
		},

		messages : {

			account_type : {
				required : "Please Select Account type",
			},

			ac_code : {
				required : "Please enter Account Code",
			},
			 
			 ac_name: {
				required : "Please enter Account Name",
			},
			
			ac_group : {
				required : "Please Select Account Group ",
			},
			
			Opening_bal : {
				required : "Please enter Opening Balance ",
			},
		},
		highlight : function(element) {
			var id_attr = "#" + $(element).attr("id") + "1";
			$(element).closest('.form-group').removeClass('has-success').addClass('has-error');
			$(id_attr).removeClass('glyphicon glyphicon-ok').addClass('glyphicon glyphicon-remove');
		},
		unhighlight : function(element) {
			var id_attr = "#" + $(element).attr("id") + "1";
			$(element).closest('.form-group').removeClass('has-error').addClass('has-success');
			$(id_attr).removeClass('glyphicon glyphicon-remove').addClass('glyphicon glyphicon-ok');
		},
		errorElement : 'span',
		errorClass : 'help-block',
		errorPlacement : function(error, element) {
			if (element.length) {
				error.insertAfter(element);
			} else {
				error.insertAfter(element);
			}
		}
});
	
	function check_account_name_exist()
	{
       var inward_from=document.getElementById('inward_from').value;
	   inward_from_name=$("#inward_from option:selected").text();
	  
       $.ajax
       ({
			url: "<?php echo site_url('ajax_validation/check_account_name_exist'); ?>",
			type: 'POST',
			dataType: "json",
			data: {ac_name: inward_from_name},
			success: function(msg) {
				//alert(msg);
				if(msg !=0)
				{
					alert("Account Name Already Exits");
					$('#inward_from').val('');
				}
				
		}
		});
	}

</script>
